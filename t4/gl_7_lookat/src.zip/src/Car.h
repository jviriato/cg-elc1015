#include "Point.h"

class Car
{
private:
    double acceleration_input;
    double acceleration_factor;
    double steer_input;
    double steer_factor;
    Point forward_vector;

public:
    double steerAngle();
    Car(/* args */);
    ~Car();
};

Car::Car(/* args */)
{
}

Car::~Car()
{
}



double Car::steerAngle()
{
    double steer_angle =  steer_input * steer_factor;
    forward_vector.rotateY(steer_angle);
    return steer_angle;
    
}